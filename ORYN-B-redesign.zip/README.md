# ORYN B — Founding Drop Redesign

A static, mobile-responsive storefront for `orynb.com` and the `ORYN-B-2` GitHub Pages repository. Designed around **OUTPUT**, **DEEP STATE**, and **THE DUAL** founding pair.

## How to deploy (once GitHub write access is enabled)

1. Back up the existing site. Create a new branch, not a direct edit to `main`.
2. Copy `index.html`, `styles.css`, `app.js`, and the `assets/` folder into the same paths in the repository.
3. Copy `CNAME`, `privacy.html`, and `terms.html` from this package as well, after reviewing legal text. Retain the repo’s original `assets/oryn-b-duo.png` as a backup if desired.
4. Preview through GitHub Pages or a local static web server, test on mobile, then open a pull request for review. After approval, merge to `main`.

The package is **self-contained**: cropped and optimized product images were made from the ORYN B brand-board image already in your ChatGPT Library. This was the same image used in your current GitHub repo. All site assets are now local relative paths, without third-party image hosting.

## Launch readiness — essential

- **Email:** No Omnisend form is connected. The scratch card and consent UI work, but the email form deliberately **does not collect or store addresses**. Embed the real Omnisend signup form / use the official integration before sending traffic.
- **Orders:** This is a *preview bag*. It stores selected SKUs and quantities in browser localStorage. There is no payment, no shipping quote and no order/reservation. Connect a secure hosted checkout or e-commerce platform at launch.
- **Offer:** The displayed `Buy OUTPUT, get DEEP STATE free` promotion is a planned launch offer. Final eligibility, claim limits, stacking rules, return rules, and shipping terms must be confirmed; check SKU margins before offering it.
- **Assets:** The repo only contained the duo brand-board image, not the referenced newer ZIP packshots or scratch-popup screenshots. Product cards use **real crops of that existing mockup**, not new AI generations. The black favicon is cropped from the original logo on the brand board. Replace the shots once you provide the actual newer ZIP; also verify the DEEP STATE mockup package size against the final label.
- **Motion:** Scroll-triggered reveals, progress tracking, stage capsules and a floating cap-like detail. The capsule scene is an illustrative animation—not an actual segmented bottle animation. A convincing photoreal bottle-opening animation requires actual layered packshot assets or a 3D model.
- **Copy / compliance:** The catalog ingredient quantities were checked against Supliful's official product listings on Oct 16, 2026. Review final labels and all claims with appropriate counsel before sales. Existing `privacy.html`/`terms.html` remain drafts that must be revised before processing customer data.
- **Performance:** No JS frameworks, no CSS frameworks, respect reduced motion and no giant library dependencies. Optimized self-hosted WebP images replace the 1.8 MB original image for faster delivery.

## Verified catalog references

- https://supliful.com/catalog/creatine-hydration-powder
- https://supliful.com/catalog/ashwagandha-plus-capsules

## Design principles

- One primary hero message, limited typography hierarchy, meaningful contrast, short navigation.
- Product-first layout before philosophy; no fake prices or fake reviews.
- Premium forest / cream / muted brass, athletic editorial energy.
- One clear opt-in incentive presented as a scratch reveal, with transparent terms.
