# ORYN B — GitHub Launch Site

A static, zero-build storefront for ORYN B. Designed around the brand system: dark forest green, cream, spacious typography, outcome-led product names, restrained claims, and a high-touch interaction layer inspired by modern DTC supplement sites.

## Run locally

Open `index.html` directly, or use a simple local server:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Deploy to GitHub Pages

1. Create a GitHub repository.
2. Upload `index.html`, `styles.css`, `script.js`, `privacy.html`, and `terms.html`.
3. In **Settings → Pages**, publish from the `main` branch and `/root`.

## Before taking orders

This repo is the storefront UI, not a payment/fulfillment backend. Connect the CTAs to your actual commerce platform (for example Shopify) and replace the draft Privacy/Terms pages with reviewed final policies.

Also have the final manufacturer-approved Supplement Facts panel, ingredient list, warnings, statement of identity, net quantity, business/distributor information, structure/function claim substantiation, and any required notices reviewed before printing or launching paid traffic.

The site intentionally avoids fabricated testimonials and unsupported medical/disease claims.
